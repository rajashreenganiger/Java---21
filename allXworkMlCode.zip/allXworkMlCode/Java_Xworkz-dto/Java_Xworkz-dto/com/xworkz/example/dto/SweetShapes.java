package com.xworkz.example.dto;

public enum SweetShapes {
	SQUARE,ROUND,RECTANGLE,RHOMBUS,CONE,CYLINDER,HEART,HEMISPHERE

}
