package com.xworkz.basics;

public class CreditCard {

	public static void main(String[] args) {
		
		CreditCardEstimater.expenditure(500);
	}

}