package com.xworkz.bus;

public class BusSearch {
	public static void main(String[] args) {

		//System.out.println("Total items to search" + Place.totalItems());
		Place.search("Hubli");
	}

}