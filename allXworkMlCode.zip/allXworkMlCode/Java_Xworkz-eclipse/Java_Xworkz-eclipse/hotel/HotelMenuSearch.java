package com.xworkz.hotel;

public class HotelMenuSearch {

		public static void main(String[] args) {

			System.out.println("Total items to search" + Food.totalItems());
			Food.search("Idli");
		}

	}

