package com.xworkz.phone;

public class NumberSearch {

		public static void main(String[] args) {

			System.out.println("Total items to search" + PhoneNumbers.totalItems());
			PhoneNumbers.search(9980297429l);
		}

	}