package com.xworkz.celebration.functional;

@FunctionalInterface
//FunctionalInterface has only one abstract method
public interface Display {
	void print(String str);
	//void print(String str, String str1);

}

