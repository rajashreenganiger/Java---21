package com.xworkz.celebration.service;

import com.xworkz.celebration.functional.Display;

public interface DisplayService {
	void printString(Display display);
}
