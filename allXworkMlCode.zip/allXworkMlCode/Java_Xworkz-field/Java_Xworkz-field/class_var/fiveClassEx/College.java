public class College{
	public static String name="SKSVMACET";
	public static short branches=6;
	public static int students=1500;
	public static String location=10.0f;
	public static float area=25.5;
}