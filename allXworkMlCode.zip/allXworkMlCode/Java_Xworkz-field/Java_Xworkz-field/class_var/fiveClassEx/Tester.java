public class Tester{
	public static void main(String[] args){
		System.out.println(" college name:"+College.name);
		System.out.println("branches:"+College.branches);
		System.out.println("students:"+College.students);
		System.out.println("place:"+College.location);
		System.out.println(" college area:"+College.area);
		
		System.out.println("------------------------------");
		System.out.println(" mobile name:"+Mobile.name);
		System.out.println("memory size:"+Mobile.ROM);
		System.out.println("battery capacity:"+Mobile.battery);
	    System.out.println("android version:"+Mobile.version);
			
        System.out.println("------------------------------");  
		System.out.println("Traniee name:"+Traniee.name);
		System.out.println(" RollNo:"+Traniee.rollNo);
		System.out.println("Organization:"+Traniee.org);
		System.out.println("place:"+Traniee.location);
		
		System.out.println("------------------------------");
		System.out.println("State name:"+State.name);
		System.out.println("Number of districts:"+StatenoOfDis.);
		System.out.println("population:"+State.population);
		System.out.println("capital city:"+State.capital);
		
		
	}
}