public class Traniee{
	public static String name="Mala";
	public static short rollNo=29;
	public static String org="X-workz";
	public static String location="Bangalore";
}