public class Mobile{
	public static String name="Oppo";
	public static short ROM=64;
	public static int battery=5000;
	public static float version=10.0f;
}