public class State{
	public static String name="Karnataka";
	public static short noOfDist=30;
	public static long population=69586993L;
	public static String capital="Bangalore";
}