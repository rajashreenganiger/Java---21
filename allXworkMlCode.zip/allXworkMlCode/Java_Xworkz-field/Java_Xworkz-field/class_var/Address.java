public class Address{	
	public static short doorNo=202;
	public static String city="laxmeshwar";
	public static String street="Hubli road";
	public static int pincode=582116;
    public static byte blockNo;
	public static String dist;	
}