public class Country{
	public static String name="India";
	public static byte noOfStates=29;
	public static String capital="Delhi";
	public static long population=1352642280L;
	public static float literacy=77.7f;
	public static String[] landmarks={"Taj mahal","Delhi Red Fort","Golden Temple","Hampi"};
}