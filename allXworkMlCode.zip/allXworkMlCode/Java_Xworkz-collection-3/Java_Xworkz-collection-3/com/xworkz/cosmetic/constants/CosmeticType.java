package com.xworkz.cosmetic.constants;

public enum CosmeticType {
	PRIMER,TONER,FOUNDATION,LIPSTICK,EYELINER,EYESHADOW,COMPACT,BLUSH,KAJAL

}
