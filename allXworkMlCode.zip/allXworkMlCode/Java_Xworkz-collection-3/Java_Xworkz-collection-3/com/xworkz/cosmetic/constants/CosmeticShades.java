package com.xworkz.cosmetic.constants;

public enum CosmeticShades {
	IVORY,LIGHT,TAN,DARK,WHITE,BLUE,BLACK,PINK,RED,PURPLE

}
