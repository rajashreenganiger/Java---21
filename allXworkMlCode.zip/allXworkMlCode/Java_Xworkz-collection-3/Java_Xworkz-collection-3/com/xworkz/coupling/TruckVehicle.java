package com.xworkz.coupling;

public class TruckVehicle implements Vehicle {
	@Override
	public void move() {
		System.out.println("truck is moving");
	}
}
