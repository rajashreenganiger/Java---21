package com.xworkz.coupling;

public class ScootyVehicle implements Vehicle {

	

		@Override
		public void move() {
			System.out.println("scooty is moving");
		}

}
