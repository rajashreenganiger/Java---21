package com.xworkz.coupling;

public interface Vehicle {

	void move();

}
