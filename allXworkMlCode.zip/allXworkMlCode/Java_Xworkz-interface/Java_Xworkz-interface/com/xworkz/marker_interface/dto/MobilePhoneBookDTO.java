package com.xworkz.marker_interface.dto;

public class MobilePhoneBookDTO extends PhoneBookDTO {

}
