package com.xworkz.marker_interface.clone;
/**
 *Cloneable is marker interface which  indicates the cloning of the object
 */
public interface CustomCloneable extends Cloneable{

}
