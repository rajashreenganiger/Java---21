package com.xworkz.redbus.contract;

public interface Contract {
	 
	 public int maxBooking();

}
