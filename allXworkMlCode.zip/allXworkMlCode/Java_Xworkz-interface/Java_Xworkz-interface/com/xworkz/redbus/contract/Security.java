package com.xworkz.redbus.contract;

public interface Security {
	public void open();

}
