public class Flavor{
  public static void taste(String[] name){
     System.out.println("Sweet name @ index 0: "+name[0]);
     System.out.println("Sweet name @ index 1: "+name[1]);
     System.out.println("Sweet name @ index 2: "+name[2]);
   }
}
