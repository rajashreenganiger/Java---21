class Wish
{
//main method is entry point to run sourcecode
public static void main(String[] mala)
{
System.out.println("Namaskara");
}
}
class Camera
{
public static void main(String[] mala)
{
System.out.println("hi");
}

}