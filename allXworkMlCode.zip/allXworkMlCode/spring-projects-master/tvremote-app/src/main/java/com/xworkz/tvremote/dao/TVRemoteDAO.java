package com.xworkz.tvremote.dao;

import com.xworkz.tvremote.entity.TvRemoteEntity;

public interface TVRemoteDAO {

	public void addTvRemoteEntity(TvRemoteEntity tvRemoteEntity);
}
