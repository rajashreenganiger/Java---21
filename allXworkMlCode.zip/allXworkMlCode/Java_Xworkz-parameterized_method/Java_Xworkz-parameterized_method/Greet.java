public class Greet{
  public static void main(String[] args){
	printMsg("Welcome");  
  }
  public static void printMsg(String wc)
  {
	  System.out.println(wc+" to X-workz");
  }
}