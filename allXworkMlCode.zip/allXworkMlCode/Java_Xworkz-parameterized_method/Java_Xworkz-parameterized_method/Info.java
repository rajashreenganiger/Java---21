public class Info{
   public static void main(String[] params)
   {
	email("mala.xworkx@gmail.com");
    programmingLang("Java");	
   }
   public static void email(String id){
	   System.out.println("Email address:"+id);
   }
   public static void programmingLang(String name){
	   System.out.println("Programming Language:"+name);
   }
}