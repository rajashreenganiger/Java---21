public class FinalVar{
	public static void main(String[] args){
		
		final long adharNo=951974281786L;
		System.out.println("Adhar number:"+adharNo);
		final long mobile=7829008765L;
		System.out.println("Phone number:"+mobile);
		final String email="mala.xworkz@gmail.com";
		System.out.println("Email id:"+email);
	}
}