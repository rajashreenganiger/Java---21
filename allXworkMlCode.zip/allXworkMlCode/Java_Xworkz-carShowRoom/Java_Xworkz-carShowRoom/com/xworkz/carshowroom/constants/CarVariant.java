package com.xworkz.carshowroom.constants;

public enum CarVariant {
	TOP,MID,BASE

}
