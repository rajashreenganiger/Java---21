class MethodDemo{
public static void main(String[] params)
{
write();
write();
write();
}
 public static void write(){
System.out.println("aspire to inspire before we expire");
}
}