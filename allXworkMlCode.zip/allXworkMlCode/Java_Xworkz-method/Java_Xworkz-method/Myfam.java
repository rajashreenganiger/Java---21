class Family{
public static void main(String[] args)
{
System.out.println("My name is Mala");
father();
mother();
brother();
sister();
}
 static void father()
{
System.out.println("My father name is Mouneshwar");
}
 static void mother()
{
System.out.println("My mother name is Lalita");
}
static void brother()
{
System.out.println("My bro name is Omkar");
}
static void sister()
{
System.out.println("My sis name is Madhu");
}
}