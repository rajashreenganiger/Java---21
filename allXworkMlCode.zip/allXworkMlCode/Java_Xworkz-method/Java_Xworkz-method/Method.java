class Hello{
public static void main(String[] params)
{
music();
drinking();
}

public static void music(){
System.out.println("When music hits you,you feel no pain");
}
public static void drinking(){
System.out.println("Drink lot of water stay hydrated");
}
}