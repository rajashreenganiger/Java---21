package com.xworkz.incomplete.states;

import com.xworkz.incomplete.scheme.UnionGovernment;

public class KarnatakaGovernment extends UnionGovernment{
	public KarnatakaGovernment() {
		System.out.println("Created KarnatakaGovernment");
	}
	@Override
	public void ayushmanBharat() {
		System.out.println("invoked ayushmanBharat");

	}

}




