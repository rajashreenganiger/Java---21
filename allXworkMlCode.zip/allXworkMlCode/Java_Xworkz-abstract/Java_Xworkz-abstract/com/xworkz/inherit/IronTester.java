package com.xworkz.inherit;

import com.xworkz.inherit.material.Iron;

public class IronTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Iron iron=new Iron("iron ore");
		iron.delivery();
		iron.manufacture();
		

	}

}
