class DisplayName
{
public static void main(String[] params)
{
System.out.println("Mala");
}
}