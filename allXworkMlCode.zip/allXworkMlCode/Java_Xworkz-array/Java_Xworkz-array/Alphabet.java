public class Alphabet{
   public static void main(String[] args){
	arrayOfChar();   
   }
   public static void arrayOfChar(){
	   char letters[]={'A','B','C','D','E','F','G','H','I','J'};
	   int size=letters.length;
	   System.out.println("Length of array is "+size);
	   
	   System.out.println("Element at index 0:"+letters[0]);
	   System.out.println("Element at index 1:"+letters[1]);
	   System.out.println("Element at index 2:"+letters[2]);
	   System.out.println("Element at index 3:"+letters[3]);
	   System.out.println("Element at index 4:"+letters[4]);
	   System.out.println("Element at index 5:"+letters[5]);
	   System.out.println("Element at index 6:"+letters[6]);
	   System.out.println("Element at index 7:"+letters[7]);
	   System.out.println("Element at index 8:"+letters[8]);
	   System.out.println("Element at index 9:"+letters[9]);  
   }
}