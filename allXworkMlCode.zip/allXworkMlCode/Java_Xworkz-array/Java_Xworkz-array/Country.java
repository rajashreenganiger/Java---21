public class Country{
public static void main(String[] states)
{
	System.out.println("JVM invoked main");
	//print refernce representation
	System.out.println("States of India"+states);
	
	int sizeOfMainParameters=states.length;
	System.out.println("size Of main parameters " +sizeOfMainParameters);
	
	System.out.println("Element @ index 0 "+states[0]);
	System.out.println("Element @ index 1 "+states[1]);
	System.out.println("Element @ index 2 "+states[2]);
	System.out.println("Element @ index 3 "+states[3]);
	System.out.println("Element @ index 4 "+states[4]);
	System.out.println("Element @ index 5 "+states[5]);
	System.out.println("Element @ index 6 "+states[6]);
	System.out.println("Element @ index 7 "+states[7]);
	System.out.println("Element @ index 8 "+states[8]);
	System.out.println("Element @ index 9 "+states[9]);
	System.out.println("Element @ index 10 "+states[10]);
	System.out.println("Element @ index 11 "+states[11]);
	System.out.println("Element @ index 12 "+states[12]);
	System.out.println("Element @ index 13 "+states[13]);
	System.out.println("Element @ index 14 "+states[14]);
	
	System.out.println("end of main");
}
}
