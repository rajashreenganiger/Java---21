package com.xworkz.sports.constants;

public enum FootWearType {
	CAUSAL,SPORTS,PARTY,FORMAL,SEMIFORMAL,TRADITIONAL,FLAT,HEELED
	}



	