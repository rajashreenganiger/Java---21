package com.xworkz.electronics.computer;

public class DellLaptop extends Laptop { 
	public void connectivity(String deviceName) {
		System.out.println("connected with the "+deviceName);
	}

}
