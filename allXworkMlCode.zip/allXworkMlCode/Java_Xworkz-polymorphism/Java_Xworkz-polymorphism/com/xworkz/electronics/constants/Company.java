package com.xworkz.electronics.constants;

public enum Company {
       HP,DELL,HCL,LENOVO,APPLE,ACER,ASUS
}
