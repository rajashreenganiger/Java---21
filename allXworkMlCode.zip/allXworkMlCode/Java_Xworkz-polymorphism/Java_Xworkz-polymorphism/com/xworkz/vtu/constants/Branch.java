package com.xworkz.vtu.constants;

public enum Branch {

	CS,IS,EC,MECH,CIVIL,EEE,IT,AERO,CHEMICAL,ROBOTICS,IP,TC,BIOTECH,ARCH,MEGATRONICS,IEE

}
