public class Datatype{
	 
	 public static void main(String[] args)
	 {
		 byte wondersOfWorld=7;
		 System.out.println(wondersOfWorld);
		 
		 short contriesInWorld=195;
		 System.out.println(contriesInWorld);
		 
		 int fastnersInAirplane=1000000;
		 System.out.println(fastnersInAirplane);
		 
		 long emailAccounts=916000000L;
		 System.out.println(emailAccounts);
		 
		 float weight=58.5f;
		 System.out.println(weight);
		 
		 double areaOfTriangle=6.7865432987;
		 System.out.println(areaOfTriangle);
		 
		 boolean isMoonStar=false;
		 System.out.println(isMoonStar);
		 
		 char attendence='P';
		 System.out.println(attendence);
		 
		 String car="Tesla";
		 System.out.println(car);
		 
	 }
 } 