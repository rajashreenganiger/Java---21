public class PrimitiveType{
	 public static void main(String[] args)
	 {
		 byte alphabet=26; 
		 short noOfRiversInIndia=400;
		 int songsOfSPB=40000;
		 long treesInAsia=255000000L;
		 float piValue=3.142f;
		 double squareRootOf20=4.472135955;
		 boolean isTomatoFruit=true;
		 char mcqQuestion='A';
		 String color="green"; 
		 System.out.println(alphabet);
		 System.out.println(noOfRiversInIndia);
		 System.out.println(songsOfSPB);
		 System.out.println(treesInAsia);
		 System.out.println(piValue);
		 System.out.println(squareRootOf20);
		 System.out.println(isTomatoFruit);
		 System.out.println(mcqQuestion);
		 System.out.println(color);
	 }
 } 