public class DatatypeEx{
	 public static void main(String[] args)
	 {
		 byte statesInIndia=29; 
		 short humanBodyBones=209;
		 int speciesInEarth=8700000;
		 long indiaPopulation=1380004385L;
		 float eyeSight=0.8f;
		 double log20=1.30102999566;
		 boolean isOneEvenNum=false;
		 char result='P';
		 String location="LXR";
		 System.out.println(statesInIndia);
		 System.out.println(humanBodyBones);
		 System.out.println(speciesInEarth);
		 System.out.println(indiaPopulation);
		 System.out.println(eyeSight);
		 System.out.println(log20);
		 System.out.println(isOneEvenNum);
		 System.out.println(result);
		 System.out.println(location);
	 }
 } 