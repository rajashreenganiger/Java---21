public enum Theater{
     PVR,Cinipolis,Urvashi,Ravi
        
}