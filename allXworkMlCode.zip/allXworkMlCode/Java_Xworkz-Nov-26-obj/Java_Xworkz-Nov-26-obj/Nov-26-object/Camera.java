
public class Camera {
	public static String brand="Panasonic";
	public static String founder="Konosuke Matsushita";
	public String type="Lumix";
	public String color="black";
	public int price=138990;
	public String manualFocus="yes";
}