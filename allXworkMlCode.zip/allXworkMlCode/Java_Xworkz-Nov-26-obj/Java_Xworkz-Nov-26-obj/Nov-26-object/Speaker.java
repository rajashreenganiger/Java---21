
public class Speaker {
 public String brand="Sony";
 public String type="loudspeaker";
 public int price=1800;
}