public class ThiefTester{



public static void main(String[] runT)
{
System.out.println("JVM invoked main");
		Thief.steal();
System.out.println("EXIT :: main");

}	
	
}