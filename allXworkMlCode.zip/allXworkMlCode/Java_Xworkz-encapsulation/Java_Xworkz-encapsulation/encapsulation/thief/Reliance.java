  
public class Reliance{
	
	
	private static double budget=45.67;
	
	
	//getter 
	public static double getBudget()
	{
		System.out.println("budget is read only");
		return budget;
	}
	
}