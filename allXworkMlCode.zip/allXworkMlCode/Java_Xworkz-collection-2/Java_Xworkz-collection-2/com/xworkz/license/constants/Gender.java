package com.xworkz.license.constants;

public enum Gender {
      MALE,FEMALE,OTHER
}
