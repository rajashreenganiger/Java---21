package com.xworkz.license.constants;

public enum VehicleType {
TWO_WHEELER,THREE_WHEELER,HEAVY,LMV
}
