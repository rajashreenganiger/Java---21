package com.xworkz.license.constants;

public enum IdProof {
ADHAR,VOTERID,PAN,PASSPORT,MARKSCARD, RATIONCARD
}
