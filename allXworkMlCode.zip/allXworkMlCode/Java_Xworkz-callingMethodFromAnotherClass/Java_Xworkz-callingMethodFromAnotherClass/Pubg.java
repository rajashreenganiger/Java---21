public class Pubg{
	public static void enimiesAhed(){
		System.out.println("enimiesAhed method is called in class Toy");
	}
}