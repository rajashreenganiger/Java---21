package com.xworkz.work;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class Email {
	
	public static void main(String[] args) {
		Collection<String> mailIds=new ArrayList();
		String mala="mala@gmail.com";
		String madhu="madhu@gmail.com";
		String omkar ="omkar@gmail.com";
		String pavitra="pavitra@gmail.com";
		String rani="rani@gmail.com";
		String asha="asha@gmail.com";
		String shree="shree@gmail.com";
		String rekha="rekha@gmail.com";
		String ravi="ravi@gmail.com";
		String laxmi="laxmi@gmail.com";
		String poorvi="poorvi@gmail.com";
		String abc="abc@gmail.com";
		String sahana="sahana@gmail.com";
		String varna="varna@gmail.com";
		String jnana="jnana@gmail.com";
		String ram="ram@gmail.com";
		
		mailIds.add("omkar@gmail.com");
		mailIds.add(mala);
		mailIds.add(madhu);
		mailIds.add(omkar);
		mailIds.add(mala);
		mailIds.add(pavitra);
		mailIds.add(rani);
		mailIds.add(asha);
		mailIds.add(ravi);
		mailIds.add(poorvi);
		mailIds.add(varna);
		mailIds.add(ram);
		mailIds.add(sahana);
		mailIds.add(laxmi);
		mailIds.add(madhu);
		mailIds.add(ravi);
		mailIds.add(mala);
		Iterator iterator=mailIds.iterator();
		
		

		
		
		
	}

}
