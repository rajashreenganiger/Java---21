package com.xworkz.weapon.interfaceClasses;

public interface Weapon {
	public static final String COUNTRY = "CHINA";

	void damage();

	void abort();

}
