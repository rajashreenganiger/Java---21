package com.xworkz.weapon.interfaceClasses;

public interface GunWeapon extends Weapon {
	String COUNTRY = "America";

	void trigger();

}
