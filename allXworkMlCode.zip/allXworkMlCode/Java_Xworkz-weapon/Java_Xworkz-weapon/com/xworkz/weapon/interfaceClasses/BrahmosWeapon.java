package com.xworkz.weapon.interfaceClasses;

public interface BrahmosWeapon extends Weapon {
	String COUNTRY="INDIA";
	 void attack();

}
