package com.xworkz.web.servlet;

import javax.servlet.http.HttpServlet;

public class AkashServlet extends HttpServlet{
	
	public AkashServlet() {
		System.out.println(this.getClass().getSimpleName()+"created");
	}
	
}
