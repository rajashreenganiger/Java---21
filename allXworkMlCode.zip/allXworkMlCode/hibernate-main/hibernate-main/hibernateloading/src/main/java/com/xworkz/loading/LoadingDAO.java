package com.xworkz.loading;

public interface LoadingDAO {
	
	public void getDetails();

	public void getDetails(int id);
}
