package com.xworkz.loading;

public class AppRunner {

	public static void main(String[] args) {
		
//		new LoadingDAOImpl().getDetails();
		new LoadingDAOImpl().getDetails(1);
	}
}
