package com.xworkz.inheritance.bekary;

public class HoneyCake extends Cake {
	private boolean honey;

	public boolean isHoney() {
		return honey;
	}

	public void setHoney(boolean honey) {
		this.honey = honey;
	}
	

}
