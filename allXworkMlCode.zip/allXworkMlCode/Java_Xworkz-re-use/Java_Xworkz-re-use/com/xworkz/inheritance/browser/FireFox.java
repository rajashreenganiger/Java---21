package com.xworkz.inheritance.browser;

public class FireFox extends Browser{

	private String version;

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}
}



